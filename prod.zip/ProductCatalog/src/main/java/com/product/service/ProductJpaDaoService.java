package com.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.entity.Product;
import com.product.repository.ProductRepo;

@Service
public class ProductJpaDaoService implements ProductService {

	@Autowired
	private ProductRepo productrepo;
	
	@Override
	public List<Product> getAllProduct() {
		
		return productrepo.findAll();
	}

	

	@Override
	public Product addProduct(Product product) {
	
		return productrepo.save(product);
	}

	@Override
	public Product deleteProductById(long id) {
	
		productrepo.deleteById(id);
		return null ;
	}



//	@Override
//	public Product getProductById(long id) {
//	productrepo.findAllById(id)
//		return null;
//	}



	@Override
	public Optional<Product> getProductById(long id) {
		 return productrepo.findById(id);
	}

}
