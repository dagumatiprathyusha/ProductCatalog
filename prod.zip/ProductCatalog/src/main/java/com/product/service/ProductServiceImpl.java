//package com.product.service;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import com.product.entity.Product;
//
//@Service
//public class ProductServiceImpl implements ProductService{
//
//	private List<Product> allProducts;
//	
//	 public ProductServiceImpl() {
//	        loadProducts();
//	    }
//
//	
//	@Override
//	public List<Product> getAllProduct() {
//		 return new ArrayList<>(allProducts);
//	}
//		
//		public void loadProducts() {
//	    allProducts=new ArrayList<>();
//		//product1
//		Product product1=new Product();
//		product1.setId(1);
//		product1.setDescription("metal bottle");
//		product1.setPrice(449);
//		product1.setImageurl("http://metalbottle.com");
//		//product2
//		Product product2=new Product();
//		product2.setId(2);
//		product2.setDescription("plastic bottle");
//		product2.setPrice(290);
//		product2.setImageurl("http://plasticbottle.com");
//		//product3
//		Product product3=new Product();
//		product3.setId(3);
//		product3.setDescription("polyster bottle");
//		product3.setPrice(290);
//		product3.setImageurl("http://polysterbottle.com");
//		//product4
//		Product product4=new Product();
//		product4.setId(4);
//		product4.setDescription("bottle");
//		product4.setPrice(290);
//		product4.setImageurl("http://bottle.com");
//		
//		Product product5=new Product();
//		product5.setId(5);
//		product5.setDescription("sampleproduct");
//		product5.setPrice(90.0);
//		product5.setImageurl("http://product5.com");
//		
//		allProducts.add(product1);
//		allProducts.add(product2);
//		allProducts.add(product3);
//		allProducts.add(product4);
//		allProducts.add(product5);
//		
//	}
//	
//	public Product getProductById(long id) {
//		int no=(int) (id-1);
//		Product product=allProducts.get(no);
//		return product;
//	}
//
//
//	@Override
//	public Product deleteProductById(long id) {
//		int no=(int) (id-1);
//		return allProducts.remove(no);
//		
//	}
//
//	@Override
//	public Product addProduct(Product product) {
//		System.out.println(allProducts.size());
//		
//	        if (product != null){
//	        	
//	        	long productId=product.getId();
//	            if (productId == 0){
//	                product.setId(allProducts.size()+1);
//	                allProducts.add(product);
//	            }
//                    //  allProducts.add(product);
//	          	            return product;
//	        }
//		else {
//            throw new RuntimeException("Product Can't be nill");
//        }
//
//
//	}
//
//
//	
//	
//
//}
