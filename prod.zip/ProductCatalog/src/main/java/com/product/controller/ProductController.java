package com.product.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.product.entity.Product;
import com.product.service.ProductJpaDaoService;

@Controller
public class ProductController {
	
	@Autowired
	ProductJpaDaoService productservice;
	
		@RequestMapping("/products")
	public String getAllProducts(Model model)
	{
		model.addAttribute("allProducts", productservice.getAllProduct())	;
		return "getAllProducts";
	}
	
		
	@RequestMapping("/products/{id}")
	public String getProductById(@PathVariable long id,Model model)
	{
		
//			model.addAttribute("product", productservice.getProductById(id));
//			return ("getProductById");

			Optional<Product> product = productservice.getProductById(id);
			if(product.isPresent()) {
	        model.addAttribute("product", product.orElse(null));
	        return "getProductById";
			}
			else {
				return "noProduct";
			}
		
		
		
		
		
		
//			model.addAttribute("product", productservice.getProductById(id));
//		return Optional.ofNullable("getProductById");
	}
		
		
		
    @RequestMapping("/product/edit/{id}")
		public String edit(@PathVariable long id,Model model)
		{
			model.addAttribute("product", productservice.getProductById(id));
			return "productform";
		}
	
		@RequestMapping("/product/add")
	public String addNewProduct(Model model)
	{
		model.addAttribute("product", new Product());	
		return "productform";
				
	}
		@RequestMapping(value="/products" ,method=RequestMethod.POST)
		public String saveProduct(Product product)
		{
		
			Product saveProduct=productservice.addProduct(product);
			saveProduct.getId();
			return "redirect:/products";
			
		}
 
		
	
		@RequestMapping("/product/delete/{id}")
	public String deleteProductById(@PathVariable long id,Model model)
	{
		model.addAttribute("product", productservice.deleteProductById(id));
		return "redirect:/products"; 
	}

}
